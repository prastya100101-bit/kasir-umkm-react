# KASIR UMKM — Frontend (React)

Frontend baru untuk KASIR UMKM, rebuild total dari `app.js` (vanilla JS) ke React.

## Stack
- **Vite** — build tool
- **React 19**
- **Tailwind CSS v4** — styling (lewat `@tailwindcss/vite`, tanpa `tailwind.config.js` terpisah, token ada di `src/index.css`)
- **Zustand** — state lokal (lokasi aktif)
- **React Query** (`@tanstack/react-query`) — data fetching dari backend
- **axios** — HTTP client
- **react-router-dom** — routing

## Struktur folder
```
src/
  api/            # axios client + fungsi panggil endpoint (auth, dst)
  store/          # Zustand store (lokasi aktif)
  context/        # AuthContext (sesi login, role user)
  routes/         # ProtectedRoute (guard halaman butuh login)
  components/
    layout/       # Sidebar, TopBar, AppLayout, LocationSwitcher
  pages/          # LoginPage, DashboardPage, ComingSoonPage (placeholder fitur lain)
  index.css       # design tokens (warna, font) + import Tailwind
  App.jsx         # routing
  main.jsx        # entry point, provider (QueryClient, dst)
```

## Yang sudah jadi (Hari 1)
- Layout dasar (sidebar + topbar) dengan navigasi role-based (Super Admin / Manager / Kasir)
- Dropdown lokasi di header (state-nya sudah jalan, tinggal disambungkan ke endpoint lokasi backend)
- Halaman login yang manggil `POST /api/auth/login` ke backend Railway
- AuthContext: simpan token, pulihkan sesi otomatis saat refresh, auto-redirect ke login kalau token expired (401)
- Dashboard placeholder per role (kartu ringkasan masih data contoh)
- Halaman placeholder untuk 5 fitur lain (margin, stock rebalancing, rekonsiliasi, dst) — tinggal diisi di hari-hari berikutnya

## Yang BELUM dibangun (langkah selanjutnya, sesuai roadmap)
- Hari 2-3: Dashboard 3-level sungguhan (sambungkan ke endpoint backend, bukan data contoh) + fetch data lokasi sungguhan untuk dropdown
- Hari 4: Edit margin per-lokasi + drill-down navigation
- Hari 5: Stock rebalancing (form create + history)
- Hari 6: Dashboard rekonsiliasi (3 alert card + settings modal) — backend-nya sudah terverifikasi cocok spec

## Menjalankan di lokal
```bash
npm install
cp .env.example .env   # lalu isi VITE_API_BASE_URL kalau perlu beda dari default
npm run dev
```
Default `VITE_API_BASE_URL` sudah mengarah ke backend production Railway
(`https://kasirumkm-production.up.railway.app`) kalau `.env` tidak diisi.

## Push ke GitHub (repo `kasir-umkm-react`)
```bash
git init                                   # kalau belum ada .git
git remote add origin <URL_REPO_KAMU>      # skip kalau remote sudah ada
git add .
git commit -m "Hari 1: scaffold Vite+Tailwind+Zustand+React Query, layout, login, dashboard placeholder"
git push -u origin main
```

## Deploy ke Vercel
1. Login ke [vercel.com](https://vercel.com) pakai akun GitHub yang sama.
2. **Add New → Project** → pilih repo `kasir-umkm-react`.
3. Framework preset otomatis terdeteksi **Vite** (build command `npm run build`, output `dist`).
4. **Environment Variables** → tambahkan:
   - `VITE_API_BASE_URL` = `https://kasirumkm-production.up.railway.app`
5. Klik **Deploy**. Setelah itu, tiap `git push` ke branch `main` otomatis trigger deploy baru.

File `vercel.json` sudah disiapkan supaya routing client-side (React Router) tidak 404
saat halaman di-refresh langsung di Vercel.

## Catatan login testing
Backend sudah punya 3 user testing sesuai dokumen project:
- `admin@kasir.local` (Super Admin)
- `manager@kasir.local` (Manager)
- `kasir@kasir.local` (Kasir)

Kalau path endpoint login (`/api/auth/login`) atau bentuk response-nya beda dari yang
diasumsikan di `src/api/auth.js` dan `src/context/AuthContext.jsx`, sesuaikan di kedua
file itu.
